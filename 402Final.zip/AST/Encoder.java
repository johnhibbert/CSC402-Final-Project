// statement list

public class Encoder extends AST {

	//NOT YET CHANGED

	public Encoder() {
	
	}

}
