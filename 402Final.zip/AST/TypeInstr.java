public class TypeInstr extends AST {

	public TypeInstr(AST a) {
	this.addAST(a);
	}
}
