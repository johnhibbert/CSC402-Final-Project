public class ImageExpr extends AST {


	public ImageExpr() {
	}
}
